import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import { createBrowserRouter } from 'react-router-dom';
import ErrorPage from './pages/ErrorPage';
import Layout from './components/Layout';
import Home from './pages/Home';
import Login from './pages/login';
import Logout from './pages/logout';
import Register from './pages/Register';
import Authors from './pages/Authors';
import AuthorPosts from './pages/AuthorPosts';
import CategoryPosts from './pages/CategoryPosts';
import PostDetail from './pages/PostDetail';
import CreatePost from './pages/CreatePost';
import EditPost from './pages/EditPost';
import DeletePost from './pages/DeletePost';
import UserProfile from './pages/UserProfile';
import { BrowserRouter } from 'react-router-dom';


const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout/>,
    errorElement: <ErrorPage/>,
    children: [
      {index:true, element: <Home/>},
      {path: "login", element: <Login/>},
      {path: "logout", element: <Logout/>},
      {path: "register", element: <Register/>},
      {path: "authors", element: <Authors/>},
      {path: "author/:id", element: <AuthorPosts/>},
      {path: "category/:id", element: <CategoryPosts/>},
      {path: "post/:id", element: <PostDetail/>},
      {path: "create-post", element: <CreatePost/>},
      {path: "edit-post/:id", element: <EditPost/>},
      {path: "delete-post/:id", element: <DeletePost/>},
      {path: "user-profile", element: <UserProfile/>},
    ]
  }
]);
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <BrowserRouter router={router} />
  </React.StrictMode>
);


