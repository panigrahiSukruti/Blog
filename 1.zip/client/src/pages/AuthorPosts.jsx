import React from 'react'

const AuthorPosts = () => {
  return (
    <div>AuthorPosts</div>
  )
}

export default AuthorPosts