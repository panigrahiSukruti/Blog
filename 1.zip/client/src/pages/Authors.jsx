import React from 'react'

const Authors = () => {
  return (
    <div>Authors</div>
  )
}

export default Authors