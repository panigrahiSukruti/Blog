import React from 'react'

const DeletePost = () => {
  return (
    <div>DeletePost</div>
  )
}

export default DeletePost