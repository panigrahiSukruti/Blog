import React from 'react'

const CategoryPosts = () => {
  return (
    <div>CategoryPosts</div>
  )
}

export default CategoryPosts