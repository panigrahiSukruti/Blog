import React from 'react'

const login = () => {
  return (
    <div>login</div>
  )
}

export default login