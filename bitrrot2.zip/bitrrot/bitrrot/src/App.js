import React from 'react';
import ReactDOM from 'react-dom';
import ImageGallery from './components/ImageGallery'; // Adjust the import path as necessary

const App = () => {
  return (
    <div>
      <ImageGallery />
      
    </div>
  );
};

export default App;