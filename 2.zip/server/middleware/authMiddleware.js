const jwt = require('jsonwebtoken')
const HttpError = require('../models/errorModel')

const authMiddleware = (req, res, next) => {
    const Authorization = req.headers.authorization || req.headers.Authorization;
    console.log(Authorization);
    if(Authorization && Authorization.startsWith('Bearer')) {
        const token = Authorization.replace('Bearer ', '')
        jwt.verify(token, process.env.JWT_SECRET, (err, info) => {
            console.log(token);
            if(err) {
                console.log(err)
                return next(new HttpError("Unauthorized", 403))
            }
            req.user = info
            next()
        })
    } else{
        return next(new HttpError("Unauthorized", 402))
    }
}
     
module.exports = authMiddleware