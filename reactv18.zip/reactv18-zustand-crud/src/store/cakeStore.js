import axios from 'axios';
import { create } from 'zustand'
import { devtools } from 'zustand/middleware'
import { immer } from 'zustand/middleware/immer';
export const useCakeStore = create(devtools(immer((set) => ({
    cakeData: [
        ],
        getCakesAPI: async () => {
            const apiResponse = await axios.get('http://localhost:7000/cakes');
            set((state)=>{
                state.cakeData = apiResponse.data
            })
    },
    addCakesAPI: async (payload) => {
        const apiResponse = await axios.post('http://localhost:7000/cakes', payload);
        set((state)=>{
            state.cakeData.push( apiResponse.data);
        })
    },
    updateCakesAPI: async (payload) => {
        const apiResponse = await axios.put(`http://localhost:7000/cakes${payload.id}`, payload);
        set((state)=>{
            let cakeState = state.cakeData.filter(c=>c.id!==payload.id);
            cakeState.push(apiResponse.data);
            state.cakeData = cakeState;
        })
    },
    deleteCakesAPI: async (id) => {
        const apiResponse = await axios.delete(`http://localhost:7000/cakes/${id}`);
        set((state)=>{
            let cakeState = state.cakeData.filter(c=>c.id!==id);
            state.cakeData = cakeState;
        })
    }
}))));

export const getCakeById = (id) => {
    return (state)=>{
        let cake = state.cakeData.filter(c=>c.id===id);
        if(cake){
            return cake[0];
        }
        return null;
    }
} 